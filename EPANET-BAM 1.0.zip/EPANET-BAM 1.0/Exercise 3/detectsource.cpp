/*
*******************************************************************************

DETECTSOURCE.CPP -- EPANET-BAM <-> PEST Source Detection Driver Script
                    for Single-Source Networks

VERSION:     EPANET-BAM Tutorial v1.0
DATE:        01/08/08
AUTHOR:      Siri Sahib Khalsa
             Sandia National Laboratories

Copyright 2007 Sandia Corporation. Under the terms of Contract 
DE-AC04-94AL85000 with Sandia Corporation, the U.S. Government 
retains certain rights in this software.

This program is is free software: 
you can redistribute it and/or modify it under the terms of the 
GNU Lesser General Public License as published by the Free Software
Foundation, either version 3 of the License, or (at your option) 
any later version.

This program is distributed in the hope that it will be useful, but 
WITHOUT ANY WARRANTY; without even the implied warranty of 
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU 
Lesser General Public License for more details.

A copy of the GNU Lesser General Public License is included in the
file COPYING-LESSER.TXT along with this program.  The GNU Lesser General
Public License is also available at <http://www.gnu.org/licenses/>.

**********************************************************************
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <process.h>
#include <vector>

typedef struct linkstruct
{
        char *value;
        struct linkstruct *next;
} strlink, *pstrlink;

typedef struct nodestruct
{
        char nodeid[50];
        float param;
        float phi;
} node, *pnode;

float getphi(char *);
float getparam(char *, char *);
int searchfile(FILE *, char *);
void setiqualnode(char *, char *);
void resetstrlist(pstrlink);
void createinp(char *, char *, char *, char);
void initnodelist(pnode);
void insertnode(pnode, pnode);
void printnodelist(char *, pnode);

const int N_RANKED_NODES = 10;

int main(int argc, char *argv[])
{
    const char PEST_BAT_PATH[] = "\"pest.bat\"";
    
    FILE *fsuspectsfile;
    node rankednodes[N_RANKED_NODES];
    node currnode;
    char recfilename[100], resultsfilename[100], runpestcmd[500];
    char *casename, *tempfilename, *suspectsfilename;
    int err;

    if (argc != 4)
    {
             printf("Syntax is <case name> <template file name> <potential sources file>\n");    
             return 1;
    }
    casename = argv[1];
    tempfilename = argv[2];
    suspectsfilename = argv[3];
    
    sprintf(recfilename, "%s.rec", casename);
    sprintf(resultsfilename, "%s_sourceresults.txt", casename);
    
    fsuspectsfile = fopen(suspectsfilename, "r");
    
    initnodelist(rankednodes);
    
    sprintf(currnode.nodeid, "_BLANK");
    
    char paramname[] = "sourcequal";
    while (((err = fscanf(fsuspectsfile, "%s", currnode.nodeid)) != EOF) &&
          (strlen(currnode.nodeid) > 0))
    {
          printf("\nInspecting Node %s...\n", currnode.nodeid);
          setiqualnode(tempfilename, currnode.nodeid);
          
        sprintf(runpestcmd, "%s %s", PEST_BAT_PATH, casename);
        system(runpestcmd);
        
        currnode.param = getparam(recfilename, paramname);
        currnode.phi = getphi(recfilename);
        
        insertnode(rankednodes, &currnode);
    }
    
    fclose(fsuspectsfile);
    
    printnodelist(resultsfilename, rankednodes);
    
    printf("Source Detection Complete\n\n");
    
    return 0;
}

float getphi(char *recfilename)
{
       float phi;
              
       FILE *recfile = fopen(recfilename, "r");
       
       char searchstr1[] = "OPTIMISATION RESULTS";
       char searchstr2[] = "Objective function";
       char searchstr3[] = "Sum of squared weighted residuals (ie phi) =";
       
       searchfile(recfile, searchstr1);
       searchfile(recfile, searchstr2);
       searchfile(recfile, searchstr3);
       fscanf(recfile, "%f", &phi);
       
       fclose(recfile);
       
       return phi;
}

float getparam(char *recfilename, char *paramname)
{
      float param;
              
       FILE *recfile = fopen(recfilename, "r");
       
       char searchstr1[] = "OPTIMISATION RESULTS";
       char searchstr2[] = "Parameters";
       
       searchfile(recfile, searchstr1);
       searchfile(recfile, searchstr2);
       searchfile(recfile, paramname);
       fscanf(recfile, "%f", &param);
       
       fclose(recfile);
       
       return param;
}

int searchfile(FILE *ftxtfile, char *searchstring)
{
    char delimeters[] = {' ', '\t', '\0'};
    char checkstr[500];
    char *tempstr;
    int err;
    int foundstr;
    pstrlink firstlink = (pstrlink) malloc(sizeof(strlink));
    pstrlink currlink = NULL, templink = NULL;
    
    /* Set up linked list with each link containing a piece of the */
    /* search string, where pieces are separated by whitespace.    */
    firstlink->value = strtok(searchstring, delimeters);
    if ((tempstr = strtok(NULL, delimeters)) != NULL)
    {
          currlink = (strlink *) malloc(sizeof(strlink));
          firstlink->next = currlink;
          
          do
          {
                currlink->value = tempstr;
                if ((tempstr = strtok(NULL, delimeters)) != NULL)
                {
                   templink = (strlink *) malloc(sizeof(strlink));
                   currlink->next = templink;
                   currlink = templink;
                } else
                {
                      currlink->next = NULL;
                }
          }  while (tempstr != NULL);
    } else
    {
          firstlink->next = NULL;
    }
    
    /* Search text file for search string */
    foundstr = 0;
    err = fscanf(ftxtfile, "%s", checkstr);
    while ((foundstr == 0) && (err != EOF))
    {
    
             currlink = firstlink->next;
             if (strcmp(firstlink->value, checkstr) == 0)
             {
                if (currlink == NULL) foundstr = 1;
                while ((err != EOF) && (foundstr == 0))
                {
                      err = fscanf(ftxtfile, "%s", checkstr);
                      if (err != EOF)
                      {
                          if (currlink == NULL) foundstr = 1;
                          else
                          {
                               if (strcmp(currlink->value, checkstr) != 0) break;
                               else
                               {
                                    currlink = currlink->next;
                                    if (currlink == NULL) foundstr = 1;
                               }
                          }
                      }
                }
             } else
             {
                   err = fscanf(ftxtfile, "%s", checkstr);
             }
       
    }
           
    resetstrlist(firstlink);
    
    if (!foundstr) printf("searchfile: could not find string %s\n", searchstring);
    
    return foundstr;
}

void resetstrlist(pstrlink firstlink)
{
     pstrlink currlink, templink;
     
     currlink = firstlink->next;
     free(firstlink);
     while (currlink != NULL)
     {
           templink = currlink->next;
           free(currlink);
           currlink = templink;
     }
}
           
void setiqualnode(char *tempfilename, char *newnodeid)
{
     FILE *tempfile = fopen(tempfilename, "r+");
     char oldnode[50];
     char catheaderstr[] = "[SOURCES]";
     char strbeforenode[] = "Pattern";
     int oldnodelen, i;
     
     searchfile(tempfile, catheaderstr);
     searchfile(tempfile, strbeforenode);
     fscanf(tempfile, "%s", oldnode);
     oldnodelen = strlen(oldnode);
     
     fseek(tempfile, -1 * oldnodelen, SEEK_CUR);
     for (i=1; i<=oldnodelen; i++) fputc(' ', tempfile);
     
     fseek(tempfile, -1 * oldnodelen, SEEK_CUR);
     fprintf(tempfile, "%s", newnodeid);
     
     fclose(tempfile);
}

void initnodelist(pnode nodelist)
{
     int i;
     
     for (i=0; i <= (N_RANKED_NODES - 1); i++)
     {
         sprintf(nodelist[i].nodeid, "%s", "_BLANK");
         nodelist[i].param = 0.0;
         nodelist[i].phi = 1e30;
     }
}

void insertnode(pnode nodelist, pnode newnode)
{
     int i, j;
     
     i = (N_RANKED_NODES - 1);
     while ((i >= 0) && (newnode->phi < nodelist[i].phi)) i--;
     i++;    
     if (i <= (N_RANKED_NODES - 1))
     {
           for (j=(N_RANKED_NODES - 1); j > i; j--)
           {
               sprintf(nodelist[j].nodeid, "%s", nodelist[j-1].nodeid);
               nodelist[j].param = nodelist[j-1].param;
               nodelist[j].phi = nodelist[j-1].phi;
           }
           
           sprintf(nodelist[i].nodeid, "%s", newnode->nodeid);
           nodelist[i].param = newnode->param;
           nodelist[i].phi = newnode->phi;
     }
}

void printnodelist(char *outfilename, pnode nodelist)
{
     FILE *outfile = fopen(outfilename, "w");
     char tabs[3];
     int i;
     
     fprintf(outfile, "Node ID\t\tSourceConc\tPhi\n");
     for (i=0; i <= (N_RANKED_NODES - 1); i++)
         if (strcmp(nodelist[i].nodeid, "_BLANK") != 0)
         {
            if (strlen(nodelist[i].nodeid) > 7) sprintf(tabs, "\t");
            else sprintf(tabs, "\t\t");
            
            fprintf(outfile, "%s%s%f\t%f\n", nodelist[i].nodeid, tabs,
                          nodelist[i].param, nodelist[i].phi);
         }
                              
     fclose(outfile);
}
